/**
 * GAMECLIENT CLASS CREATES AN INSTANCE FOR CLIENT
 * @author chengwei
 *
 */
public class GameClient {

	/**
	 * CONSTRUTOR
	 */
	public GameClient() {}

	/**
	 * CLIENT MAIN FUNCTION
	 * @param args
	 */
	public static void main(String[] args) {
		new ClientGUI();
	}
}
