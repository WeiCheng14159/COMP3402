import javax.swing.JFrame;

public class Page {
	protected JFrame frame;
	protected int Window_Width = 800;
	protected int Window_Height = 400;
	
	public Page() {
		
	}
	public JFrame get_frame(){
		return frame;
	}
}
